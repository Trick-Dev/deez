import { AccountPipe } from './account.pipe';

describe('AccountPipe', () => {
  it('create an instance', () => {
    const pipe = new AccountPipe();
    expect(pipe).toBeTruthy();
  });
});
