import { SqueezePipe } from './squeeze.pipe';

describe('SqueezePipe', () => {
  it('create an instance', () => {
    const pipe = new SqueezePipe();
    expect(pipe).toBeTruthy();
  });
});
