import { RaiPipe } from './rai.pipe';

describe('RaiPipe', () => {
  it('create an instance', () => {
    const pipe = new RaiPipe();
    expect(pipe).toBeTruthy();
  });
});
