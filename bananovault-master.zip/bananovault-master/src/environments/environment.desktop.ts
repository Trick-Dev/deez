export const environment = {
  production: true,
  desktop: true,
};
