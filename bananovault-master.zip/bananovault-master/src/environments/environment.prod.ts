export const environment = {
  production: true,
  desktop: false,
};
